import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Aboutus2Page } from './aboutus2';

@NgModule({
  declarations: [
    Aboutus2Page,
  ],
  imports: [
    IonicPageModule.forChild(Aboutus2Page),
  ],
})
export class Aboutus2PageModule {}
