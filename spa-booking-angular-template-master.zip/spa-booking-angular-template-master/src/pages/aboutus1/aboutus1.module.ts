import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Aboutus1Page } from './aboutus1';

@NgModule({
  declarations: [
    Aboutus1Page,
  ],
  imports: [
    IonicPageModule.forChild(Aboutus1Page),
  ],
})
export class Aboutus1PageModule {}
